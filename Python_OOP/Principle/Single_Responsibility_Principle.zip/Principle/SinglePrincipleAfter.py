# ship 클래스가 책임을 지는 4가지 일을 여러가지 책임을 를 연료, 선원, 물자, 엔진 관련 책임 클래스로 나눌 것이다
# ship클래스는 각각의클래스를 인스턴스로 가진다. 
class ship:
    def __init__(self, fuel, fuel_per_hour, supplies, num_crew):
        self.fuel_tank = FuelTank(fuel) 
        # engine은 FuelTank 클라쓰의 인스터를 인자로 가진다. 
        self.engine = Engine(self.fuel_tank, fuel_per_hour)
        self.crew_manager = CrewManager(num_crew)
        # supply_hold는 crew_manager의 클라스를 인자로 가진다. 
        self.supply_hold = SupplyHold(supplies, self.crew_manager)
         
# 연료 클라쓰
class FuelTank:
    def __init__(self, fuel):
        self.fuel = fuel   
               
    def charge_fuel(self, amount):
        self.fuel += amount
        
    def use_fuel(self, amount):
        if self.fuel - amount >=0:
            self.fuel -= amount 
            return True
        print("연료가 부족해요!")
        return False
    def report_fuel(self):
        print("현재 연료는{}남아 있습니다".format(self.fuel))
        
# fuel_tank 클래스의 인스터스와 시간당 연료 소비량을 인스턴스 변수로 
class Engine:
    def __init__(self, fuel_tank,fuel_per_hour):
        self.fuel_tank = fuel_tank 
        self.fuel_per_hour = fuel_per_hour 
        
    def run_for_hours(self, hours):
        if self.fuel_tank.use_fuel(self.fuel_per_hour * hours):
            print("엔진을 {}시간 동안 돌립니다".format(hours))
            return True
        print("연료가 부족해서 엔직 작동을 시작할 수 없습니다")
        return False

# 선원 클라쓰
class CrewManager:
    # num_crew = 배에 탄 선원 수 
    def __init__(self, num_crew):
        self.num_crew = num_crew
        
    def load_crew(self, number):
        self.num_crew += number         
        
    def report_crew(self):
        print("현재 선원 {}명이 있습니다".format(self.num_crew))
        
        
# 물량 클라쓰 
# 물량과 선원관리 클래스의 인스턴스를 변수로 갖는다?
class SupplyHold:
    def __init__(self, supplies, crew_manager):
        self.supplies = supplies 
        self.crew_manager = crew_manager
        
    def charge_supplies(self, amount):
        self.supplies += amount 
        
    def report_supplies(self):
        print("현재 물량은{}명분 남아있습니다.".format(self.supplies))

    def distribute_supplies_to_crew(self):
        if self.supplies >= self.crew_manager.num_crew:
            self.supplies -= self.crew_manager.num_crew
            return True
        print("물자가 부족합니다")
        return False         
# ship 객체 
obj = ship(500, 10, 50, 10)

''' 
Fuel Tank  
'''
print("===== Fuel Tank ===== ")  
print("Fuel Tank 클래스는 fuel를 변수로 갖는다.")
print(" fuel를 변수",obj.fuel_tank.fuel)
print(obj.fuel_tank.report_fuel())
## FuelTank 클래스에서 연료 충전  
obj.fuel_tank.charge_fuel(20) 
print(obj.fuel_tank.report_fuel())
## FuelTank 클래스에서 연료 사용
obj.fuel_tank.use_fuel(70)
print(obj.fuel_tank.report_fuel())

'''
EnGine
'''
print("===== EnGine ===== ") 
print("Engine 클래스는 fuel_tank클래스의 객체도 인스터스로 갖는다.")
# obj.engine.fuel_tank() 하면은 colloable 
print("Fuel_tank 클래스: ",obj.engine.fuel_tank)
print("fuel_per_hour", obj.engine.fuel_per_hour)
obj.engine.run_for_hours(3)


'''
CrewManager
'''
print("===== CrewManager ===== ")
print("CrewManager 클래스는 num_crew 변수로 갖는다")
print("num_crew: ", obj.crew_manager.num_crew) 


print(obj.crew_manager.report_crew())
print("선원10명추가")
obj.crew_manager.load_crew(10)
print(obj.crew_manager.report_crew())

print("===== SupplyHold ===== ")
print("supplyhold클래스는 supplies와 crew_manager 클래스를 변수로 갖는다")
print("supplies: ", obj.supply_hold.supplies)
# obj.supply_hold.crew_manager() 하면은 TypeError: 'CrewManager' object is not callable 요런 에러남
print("crew_manager 클래스: ", obj.supply_hold.crew_manager)
# 메서드가 self만 있는 경우 ()를 쓴다. ()를 안 써주면 method의 객체만 나올뿐..
print(obj.supply_hold.report_supplies())
print(obj.supply_hold.distribute_supplies_to_crew())
