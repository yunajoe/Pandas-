'''
학생 정보 클래스
학점 클래스  
'''

# student 클래스는 학생 정보와 학점 클래스를 인스터스로 가진다.
class Student:
    def __init__(self,name,id,major):
        self.student_info = Student_info(name,id,major)
        self.score = Score()
        self.report = Report(self.student_info, self.score)    
    
# 학생 정보 클래스 
class Student_info:
    def __init__(self, name, id, major):
        self.name = name
        self.id = id
        self.major = major          
        
    def change_name(self, new_name):
        self.name = new_name
        
    def change_id(self, new_id):
        self.id = new_id
        
    def change_major(self,new_major):
        self.major = new_major
        
    # 학점 클래스     
class Score:
    def __init__(self):             
        self.grades = []
        
    def add_grade(self, grade):
        if 0 <= grade <= 4.3:
            self.grades.append(grade)
        else:
            print("수업 학점은 0과 4.3 사이여야 합니다!")
        
    def get_average_gpa(self):
        return sum(self.grades) / len(self.grades)   

# 다른 클래스들의 변수들을 가꼬와야됨     
class Report:
    def __init__(self, student_info, score):
        self.student_info = student_info
        self.score = score 
        
    def report_info(self):
        print(self.student_info.name, self.student_info.id, self.student_info.major)
        
        
        
p1 = Student("연아", 123, "econ")
p1.report.report_info()
print("=============== 성적을 추가해봅니다 =================")
p1.score.add_grade(3)
p1.score.add_grade(4)
p1.score.add_grade(3)
p1.score.add_grade(2)
print("=============== 성적 리스트들 =================") 
print(p1.score.grades)
print("=============== 보고서 출력 =================") 

p1.report.report_info()


        
     
            
         
        
