# 학생 기본 정보 
# 학점 
# 성적표 
# cf. self 만 parameter로 받을 때는 그냥 메서드이름() 만! 해준당

''' 각각의 기능을 담는 클래스를 담는 클래스를 만들자 '''

class Student:
    def __init__(self,name,id,major):
        self.student_info = StudentInfo(name,id,major)
        self.score = Score()
        self.report = Report(self.student_info, self.score)

"""학생 기본 정보 클래스"""
class StudentInfo:
    def __init__(self, name, id, major):
        self.name = name
        self.id = id 
        self.major = major        
    """학생 기본 정보 수정 메소드"""
    def change_info(self, new_name, new_id, new_major):
        self.name = new_name
        self.id = new_id 
        self.major = new_major        
    
class Score:
    def __init__(self):
        self.grades = []
    """학점 추가 메소드"""
    def add_grade(self,grade):
        if 0 <= grade <=4.5:
            self.grades.append(grade)
        else:
            print("수업 학점은 0과 4.3 사이여야 합니다!")             
    def get_average_gpa(self):
        return sum(self.grades) / len(self.grades)
    
"""성적표 출력 클래스"""
# student_info와 score 클래스를 인스턴스로 가진당
class Report:
    def __init__(self,student_info,score):
        self.student_info = student_info
        self.score = score
        
    def print(self):
        print(f"{self.student_info.name}, {self.student_info.id},{self.student_info.major},{self.score.get_average_gpa()}")
          
# 인스턴스 생성
p1 = Student("연아", 123,"econ")

# 성적을 더해보쟈 
p1.score.add_grade(3)
p1.score.add_grade(4)
p1.score.add_grade(3)
p1.score.add_grade(3)
print("==================보고서출력=======================")
p1.report.print()
print("==================정보수정=======================")
p1.student_info.change_info("연아2",456,"CS")
print("==================보고서출력=======================") 
p1.report.print()
